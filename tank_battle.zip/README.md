# Team Handmade Game

Project set up instructions

1 - Clone the repo
2 - Open a cmd prompt at the window
3 - run buildandrun.bat
